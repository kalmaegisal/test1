package com.bestcat.delivery.order.entity.type;

public enum OrderType {
    ONLINE,
    IN_PERSON
}
