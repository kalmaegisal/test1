package com.bestcat.delivery.order.entity.type;

public enum OrderStatus {
    DEFAULT,
    RECEIVED,
    CANCELLED,
    COMPLETED
}
