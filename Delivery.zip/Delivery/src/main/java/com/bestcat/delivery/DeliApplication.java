package com.bestcat.delivery;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DeliApplication {

    public static void main(String[] args) {
        SpringApplication.run(DeliApplication.class, args);
    }

}
