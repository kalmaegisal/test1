package com.bestcat.delivery.ai.dto;

public record AiResponseDto(
        String[] description
) {

}
