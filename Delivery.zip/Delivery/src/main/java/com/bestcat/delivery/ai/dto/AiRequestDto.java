package com.bestcat.delivery.ai.dto;

public record AiRequestDto(
        String name
) {
}
